import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import RegistrationTabs from './RegistrationTabs';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || "";

const defaultProfile = {
  name: "",
  email: "",
  photo: "",
  gradeLevel: "",
  dob: "",
  gender: "",
  currentFunction: "",
  address: "",
};

const defaultRegistrationData = {
  parentGuardian: {},
  emergencyContact: {},
  medical: {},
  legal: {},
};

const MAX_IMAGE_SIZE_MB = 200;

const ProfilePage = () => {
  const studentData = JSON.parse(localStorage.getItem("studentData") || "{}");
  const userId = studentData._id;

  const [profile, setProfile] = useState(defaultProfile);
  const [registrationData, setRegistrationData] = useState(defaultRegistrationData);
  const [editing, setEditing] = useState(false);
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(""); // Add to state
  const [profileLoading, setProfileLoading] = useState(true); // Add loading state
  const [showProfileInstructionModal, setShowProfileInstructionModal] = useState(true); // Add this state
  const navigate = useNavigate(); // <-- Add this line

  useEffect(() => {
    if (!userId) return;

    // Fetch profile from backend
    const fetchProfile = async () => {
      setProfileLoading(true); // Start loading
      try {
        const res = await fetch(`${API_BASE_URL}/api/profile/${userId}`);
        let profileData = {};
        if (res.ok) {
          profileData = await res.json();
        }
        // Always fetch user data for the latest name
        const resUser = await fetch(`${API_BASE_URL}/api/user/${userId}`);
        let dataUser = {};
        if (resUser.ok) {
          dataUser = await resUser.json();
        }
        setProfile((prev) => ({
          ...prev,
          ...profileData,
          name: dataUser.name || profileData.name || prev.name,
          gradeLevel: dataUser.className || dataUser.gradeLevel || profileData.gradeLevel || prev.gradeLevel,
          email: dataUser.email || profileData.email || prev.email,
          dob: dataUser.dob || profileData.dob || prev.dob,
          gender: dataUser.gender || profileData.gender || prev.gender,
        }));
      } catch (err) {
        // fallback: use localStorage or previous state
      } finally {
        setProfileLoading(false); // End loading
      }
    };

    fetchProfile();

    const savedRegistration = JSON.parse(localStorage.getItem('goshen-registration-data')) || defaultRegistrationData;
    setRegistrationData(savedRegistration);
  }, [userId]);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "photo" && files && files[0]) {
      const file = files[0];
      if (file.size > MAX_IMAGE_SIZE_MB * 1024 * 1024) {
        setError(`Image too large. Maximum size is ${MAX_IMAGE_SIZE_MB}MB.`);
        return;
      }
      setError(""); // Clear previous error
      const reader = new FileReader();
      reader.onload = (ev) => {
        setProfile((prev) => ({ ...prev, photo: ev.target.result }));
      };
      reader.readAsDataURL(file);
    } else {
      setProfile((prev) => ({ ...prev, [name]: value }));
    }
  };

  // Save profile to backend
  const handleSave = async () => {
    setSaving(true);
    setError("");
    try {
      // 1. Update Profile collection
      const res = await fetch(`${API_BASE_URL}/api/profile/${userId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profile),
      });
      if (res.ok) {
        // 2. Also update User collection with the new name
        await fetch(`${API_BASE_URL}/api/user/${userId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: profile.name }),
        });
        localStorage.setItem('studentProfile', JSON.stringify(profile));
        setEditing(false);
        // Optionally, re-fetch profile to ensure latest name is displayed
        // fetchProfile();
      } else {
        const data = await res.json();
        if (data.error && data.error.toLowerCase().includes("image")) {
          setError("There was a problem with your photo. Please use a valid image under 200MB.");
        } else {
          setError(data.error || "Failed to save profile. Please check your details and try again.");
        }
      }
    } catch (err) {
      setError("Network error. Please check your internet connection and try again.");
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  const requiredFields = [
    { key: "gender", label: "Gender" },
    { key: "dob", label: "Date of Birth" },
    { key: "address", label: "Address" },
    { key: "currentFunction", label: "Current Function" },
    { key: "gradeLevel", label: "Grade/Class" },
    { key: "photo", label: "Profile Photo" }
  ];
  const missingFields = requiredFields.filter(field => !profile[field.key] || profile[field.key] === "");

  if (profileLoading) {
    return (
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow p-4 sm:p-6 mt-6 sm:mt-10 flex flex-col items-center justify-center min-h-[300px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mb-4"></div>
        <div className="text-primary font-semibold text-lg">Loading profile details...</div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-lg shadow p-4 sm:p-6 mt-6 sm:mt-10">
      {/* Back to Dashboard button */}
      <div className="mb-2 flex justify-end">
        <button
          className="bg-secondary text-white px-4 py-2 rounded font-semibold hover:bg-secondary/90 transition"
          onClick={() => navigate('/student-dashboard')}
        >
          Back to Dashboard
        </button>
      </div>
      {/* Compulsory label */}
      <div className="mb-2">
        <span className="text-xs text-red-600 font-semibold uppercase tracking-wide">Compulsory</span>
      </div>
      <div className="flex flex-col sm:flex-row items-center mb-6 gap-4 sm:gap-6">
        <div className="flex flex-col items-center w-full sm:w-auto">
          <div className="relative flex justify-center">
            <img
              src={profile.photo || "/assets/images/default_student.png"}
              alt="Student"
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border cursor-pointer"
              onClick={() => setShowPhotoModal(true)}
              title="Click to view full photo"
              style={{ transition: "box-shadow 0.2s" }}
            />
            {/* Hidden file input for photo upload */}
            {editing && (
              <input
                id="profile-photo-input"
                type="file"
                name="photo"
                accept="image/*"
                className="hidden"
                onChange={handleChange}
                title="Change photo"
              />
            )}
          </div>
          {editing && (
            <button
              type="button"
              className="mt-2 bg-primary text-white rounded-full w-10 h-10 flex items-center justify-center shadow-lg border-2 border-white focus:outline-none focus:ring-2 focus:ring-primary transition"
              onClick={() => document.getElementById('profile-photo-input').click()}
              title="Add Profile Picture"
              tabIndex={0}
              style={{ zIndex: 2 }}
            >
              <span className="text-xs leading-none font-semibold px-2 text-center">Add<br />Profile<br />Picture</span>
            </button>
          )}
        </div>
        <div className="text-center sm:text-left w-full">
          {editing ? (
            <>
              <input
                type="text"
                name="name"
                value={profile.name}
                readOnly
                className="w-full border rounded px-2 py-1 mb-2 bg-gray-100 cursor-not-allowed"
                placeholder="Full Name"
              />
              {/* Removed email input */}
              <input
                type="text"
                name="gradeLevel"
                value={profile.gradeLevel}
                readOnly
                className="w-full border rounded px-2 py-1 mb-2 bg-gray-100 cursor-not-allowed"
                placeholder="Grade Level"
              />
              <input
                type="text"
                name="currentFunction"
                value={profile.currentFunction}
                onChange={handleChange}
                placeholder="Current Function"
                className="w-full border rounded px-2 py-1 mb-2"
              />
              <input
                type="text"
                name="address"
                value={profile.address}
                onChange={handleChange}
                placeholder="Address"
                className="w-full border rounded px-2 py-1 mb-2"
              />
              <div className="mb-2 w-full">
                <label className="block text-xs font-semibold text-gray-600 mb-1 sm:hidden">Date of Birth (DOB)</label>
                <input
                  type="date"
                  name="dob"
                  value={profile.dob}
                  onChange={handleChange}
                  className="w-full border rounded px-2 py-1"
                  placeholder="Date of Birth"
                />
              </div>
              <select
                name="gender"
                value={profile.gender}
                onChange={handleChange}
                className="w-full border rounded px-2 py-1 mb-2"
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </>
          ) : (
            <>
              <h2 className="text-xl sm:text-2xl font-bold text-primary mb-2">{profile.name || "Student Name"}</h2>
              {/* Removed email display */}
              <p className="text-base sm:text-lg font-medium mb-1">
                Grade Level: {profile.gradeLevel || "N/A"}
              </p>
              <p className="text-base sm:text-lg font-medium mb-1">
                Current Function: {profile.currentFunction || "N/A"}
              </p>
              <p className="text-base sm:text-lg font-medium mb-1">
                Address: {profile.address || "N/A"}
              </p>
              <p className="text-base sm:text-lg font-medium mb-1">Date of Birth: {profile.dob || "N/A"}</p>
              <p className="text-base sm:text-lg font-medium mb-1">Gender: {profile.gender || "N/A"}</p>
            </>
          )}
        </div>
      </div>
      {/* Photo Modal */}
      {showPhotoModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="relative bg-white rounded-lg shadow-lg p-4">
            <img
              src={profile.photo || "/assets/images/default_student.png"}
              alt="Full Student"
              className="max-w-full max-h-[80vh] rounded"
            />
            <button
              className="absolute top-2 right-2 bg-primary text-white rounded-full px-3 py-1"
              onClick={() => setShowPhotoModal(false)}
              title="Close"
            >
              Close
            </button>
          </div>
        </div>
      )}
      {error && <div className="text-red-600 mb-2">{error}</div>}
      <div className="flex gap-4 mb-4">
        {editing ? (
          <button
            className="bg-primary text-white px-4 py-2 rounded font-semibold"
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? "Saving..." : "Save"}
          </button>
        ) : (
          <button
            className="bg-primary text-white px-4 py-2 rounded font-semibold"
            onClick={() => setEditing(true)}
          >
            Edit Profile
          </button>
        )}
        {editing && (
          <button
            className="bg-gray-200 px-4 py-2 rounded font-semibold"
            onClick={() => setEditing(false)}
            disabled={saving}
          >
            Cancel
          </button>
        )}
      </div>
      {missingFields.length > 0 && showProfileInstructionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-sm text-center">
            <h3 className="font-bold text-lg mb-4 text-primary">Complete Your Profile</h3>
            <p className="mb-4 text-muted-foreground">
              To access all features, please fill in the following required profile sections:
            </p>
            <ul className="list-disc list-inside text-sm text-red-700 mb-4 text-left">
              {missingFields.map(field => (
                <li key={field.key}>{field.label}</li>
              ))}
            </ul>
            <p className="mb-4 text-sm text-gray-700">
              Click <span className="font-semibold text-primary">Edit Profile</span> to update your details.
            </p>
            <button
              className="px-6 py-2 bg-primary text-white rounded font-semibold hover:bg-primary/90"
              onClick={() => {
                setEditing(true);
                setShowProfileInstructionModal(false);
              }}
            >
              Edit Profile
            </button>
            <button
              className="ml-2 px-4 py-2 bg-muted text-foreground rounded hover:bg-muted/80 font-semibold"
              onClick={() => setShowProfileInstructionModal(false)}
            >
              Dismiss
            </button>
          </div>
        </div>
      )}
      <div className="w-full">
        <RegistrationTabs userId={userId} registrationData={registrationData} />
      </div>
    </div>
  );
};

export default ProfilePage;