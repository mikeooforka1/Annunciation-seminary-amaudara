import React, { useState, useEffect } from 'react';
import { TbFidgetSpinner } from "react-icons/tb";
import RoleBasedHeader from '../../../components/ui/RoleBasedHeader';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';
import Modal from '../../../components/ui/Modal';

const terms = [
    { value: 'first', label: 'First Term' },
    { value: 'second', label: 'Second Term' },
    { value: 'third', label: 'Third Term' }
];

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
function getGrade(score) {
  if (score >= 75 && score <= 100) return "A1";
  if (score >= 70 && score < 75) return "B2";
  if (score >= 65 && score < 70) return "B3";
  if (score >= 60 && score < 65) return "C4";
  if (score >= 55 && score < 60) return "C5";
  if (score >= 50 && score < 55) return "C6";
  if (score >= 45 && score < 50) return "D7";
  if (score >= 40 && score < 45) return "E8";
  return "F9";
}
function getRemark(grade) {
  if (grade === "A1") return "Excellent";
  if (grade === "B2" || grade === "B3") return "Very Good";
  if (grade === "C4" || grade === "C5" || grade === "C6") return "Good";
  if (grade === "D7" || grade === "E8") return "Pass";
  if (grade === "F9") return "Fail";
  return "";
}
const ResultPortal = () => {
    const [teacherData, setTeacherData] = useState(null);
    const [selectedTerm, setSelectedTerm] = useState('');
    const [students, setStudents] = useState([]);
    const [subjects, setSubjects] = useState([]);
    const [newSubject, setNewSubject] = useState('');
    const [results, setResults] = useState({});
    const [overall, setOverall] = useState({});
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [successMsg, setSuccessMsg] = useState('');
    const [errorMsg, setErrorMsg] = useState('');
    const [teacherResults, setTeacherResults] = useState([]);
    const [isLoadingStudents, setIsLoadingStudents] = useState(false);
    const [isLoadingResults, setIsLoadingResults] = useState(false);
    const [manualOverall, setManualOverall] = useState({});
    const [caScores, setCaScores] = useState({});
    const [selectedStudent, setSelectedStudent] = useState(null);
    const [resultsPushed, setResultsPushed] = useState({});
    const [showPushConfirm, setShowPushConfirm] = useState(false);
    const [pendingPushStudentId, setPendingPushStudentId] = useState(null);
    const [dirtyStudents, setDirtyStudents] = useState({}); // <-- New state for tracking dirty students
    const [showDeleteSubjectConfirm, setShowDeleteSubjectConfirm] = useState(null); // <-- New state for delete subject confirmation
    const [isGeneralPushing, setIsGeneralPushing] = useState(false);
    const [showGeneralPushConfirm, setShowGeneralPushConfirm] = useState(false);

    function buildSaveAllPayload(studentId, isPush = false) {
  const studentResults = results[studentId] || {};
  const studentSubjects = subjects || [];

  // Only include fields for current subjects
  const filteredResults = {};
  Object.keys(studentResults).forEach(key => {
    // If key is for a subject, only include if subject is in tray
    const match = key.match(/^(.+?)_/);
    if (match) {
      const subj = match[1];
      if (studentSubjects.includes(subj)) {
        filteredResults[key] = studentResults[key];
      }
    } else if (studentSubjects.includes(key) || !key.includes('_')) {
      // For keys like 'Maths', 'average', etc.
      filteredResults[key] = studentResults[key];
    }
  });

  // Calculate average if not set
  let manualAverage = filteredResults.average;
  let autoAverage = '';
  if (!manualAverage) {
    const subjectTotals = studentSubjects.map(subject => {
      const cat1 = Number(filteredResults[`${subject}_cat1`] || 0);
      const exam = Number(filteredResults[`${subject}_exam`] || 0);
      return cat1 + exam;
    });
    autoAverage =
      subjectTotals.length > 0
        ? (subjectTotals.reduce((a, b) => a + b, 0) / subjectTotals.length)
        : '';
    if (autoAverage !== '' && autoAverage > 100) autoAverage = 100;
    autoAverage = autoAverage !== '' ? Number(autoAverage).toFixed(1) : '';
  }

  return {
    studentId,
    teacherId: teacherData?._id,
    className: teacherData?.className,
    term: selectedTerm,
    subjects: studentSubjects,
    caScores: caScores[studentId] || {},
    ...filteredResults,
    ...overall[studentId],
    headTeacherRemark: "Average performance needs more improvement",
    teacherComment: "Good performance push harder",
    academicYear: "2025/2026",
    nextTerm: "25/09/2026",
    average: manualAverage !== undefined && manualAverage !== null && manualAverage !== ''
      ? manualAverage
      : autoAverage,
    isPush,
  };
  
}
    // 1. Load subjects from localStorage on mount (per class/term)
    useEffect(() => {
      const key = `resultPortal_subjects_${teacherData?.className}_${selectedTerm}`;
      const savedSubjects = localStorage.getItem(key);
      if (savedSubjects) {
        setSubjects(JSON.parse(savedSubjects));
      }
    }, [teacherData, selectedTerm]);

    // 2. Save subjects to localStorage whenever it changes
    useEffect(() => {
      if (teacherData?.className && selectedTerm) {
        const key = `resultPortal_subjects_${teacherData.className}_${selectedTerm}`;
        localStorage.setItem(key, JSON.stringify(subjects));
      }
    }, [subjects, teacherData, selectedTerm]);

    // 3. Load saved result data for selected student (including subjects)
    // ...existing code...

    // Add this useEffect to always sync subjects from backend for the class/term
   // ...existing code...
useEffect(() => {
  if (teacherData?.className && selectedTerm) {
    fetch(`${API_BASE_URL}/api/results/class/${encodeURIComponent(teacherData.className)}/${encodeURIComponent(selectedTerm)}`)
      .then(res => res.json())
      .then(data => {
        // Only include subjects that are not deleted
        const backendSubjects = Array.from(
          new Set(
            data
              .filter(
                r =>
                  r.subject &&
                  r.subject !== "Overall" &&
                  !r.subject.endsWith("C/A") &&
                  r.deleted !== true
              )
              .map(r => r.subject)
          )
        );
        setSubjects(prevSubjects => {
          // Merge backend subjects with current subjects, preserving local changes
          const merged = Array.from(new Set([...(prevSubjects || []), ...backendSubjects]));
          return merged;
        });
      });
  }
}, [teacherData, selectedTerm]);
// ...existing code...

    // Fetch and map student results when a student is selected
    useEffect(() => {
      if (
        selectedStudent &&
        teacherData?.className &&
        selectedTerm &&
        isValidObjectId(selectedStudent._id)
      ) {
        fetch(
          `${API_BASE_URL}/api/results/student/${selectedStudent._id}/all?className=${teacherData.className}&term=${selectedTerm}`
        )
          .then(res => res.json())
          .then(backendData => {
            if (!backendData || backendData.length === 0) return;

            // --- Collect all subjects from backend ---
            const backendSubjects = backendData
              .filter(item => item.subject && item.subject !== 'Overall' && !item.subject.endsWith('C/A'))
              .map(item => item.subject);

            // --- Load subjects from localStorage for this student ---
            let localSubjects = [];
            try {
              const key = `resultPortal_${teacherData?.className}_${selectedTerm}_${selectedStudent._id}`;
              const saved = localStorage.getItem(key);
              if (saved) {
                const parsed = JSON.parse(saved);
                if (Array.isArray(parsed.subjects)) {
                  localSubjects = parsed.subjects;
                }
              }
            } catch {}

            // --- Merge backend, localStorage, and current subjects ---
           setSubjects(prev => {
  // Only keep subjects that are not deleted
  const deletedSubjects = prev.filter(s => !backendSubjects.includes(s) && !localSubjects.includes(s));
  const merged = Array.from(new Set([
    ...prev.filter(s => !deletedSubjects.includes(s)),
    ...backendSubjects,
    ...localSubjects
  ]));
  return merged;
});

            // Prepare new state objects, always merge with previous state
            setResults(prevResults => {
              const prev = prevResults[selectedStudent._id] || {};
              const newResults = { ...prev };
              backendData.forEach(item => {
                if (item.subject && item.subject !== 'Overall') {
                  [
                    '_project',
                    '_cat1',
                    '_cat2',
                    '_exam',
                    '_maxScore',
                    '_minScore',
                    '_grade',
                    '_remark',
                    '_overallScore'
                  ].forEach(suffix => {
                    const key = `${item.subject}${suffix}`;
                    if (item[suffix.replace('_', '')] !== undefined) {
                      newResults[key] = item[suffix.replace('_', '')];
                    }
                  });
                  if (item.score !== undefined) {
                    newResults[item.subject] = item.score;
                  }
                }
                [
                  'handwriting', 'punctuality', 'initiative', 'obedience', 'honesty',
                  'neatness', 'attentiveness', 'respect', 'attitude', 'creativity'
                ].forEach(field => {
                  if (item[field] !== undefined) {
                    newResults[field] = item[field];
                  }
                });
                if (item.teacherComment !== undefined) newResults.teacherComment = item.teacherComment;
                if (item.signatureDate !== undefined) newResults.signatureDate = item.signatureDate;
                if (item.headTeacherRemark !== undefined) newResults.headTeacherRemark = item.headTeacherRemark;
                if (item.academicYear !== undefined) newResults.academicYear = item.academicYear;
                if (item.schoolOpened !== undefined) newResults.schoolOpened = item.schoolOpened;
                if (item.present !== undefined) newResults.present = item.present;
                if (item.absent !== undefined) newResults.absent = item.absent;
                if (item.totalScore !== undefined) newResults.totalScore = item.totalScore;
                if (item.projectDefence !== undefined) newResults.projectDefence = item.projectDefence;
                if (item.average !== undefined) newResults.average = item.average;
                if (item.nextTerm !== undefined) newResults.nextTerm = item.nextTerm;
                if (item.subject === 'Overall') {
                  if (item.score !== undefined) {
                    newResults.overallScore = item.score;
                  }
                  if (item.remarks && item.remarks.includes('Position:')) {
                    newResults.position = item.remarks.replace('Position:', '').trim();
                  }
                }
              });

              // Only remove fields for subjects that have been removed
              const validSubjects = new Set(subjects);
              Object.keys(newResults).forEach(key => {
                const match = key.match(/^(.+?)_/);
                if (match) {
                  const subj = match[1];
                  if (!validSubjects.has(subj)) {
                    delete newResults[key];
                  }
                } else if (!validSubjects.has(key) && key.match(/^[A-Za-z ]+$/)) {
                  // Remove main subject score if subject removed
                  delete newResults[key];
                }
              });

              return { ...prevResults, [selectedStudent._id]: newResults };
            });

            setOverall(prevOverall => {
              const prev = prevOverall[selectedStudent._id] || {};
              const newOverall = { ...prev };
              backendData.forEach(item => {
                if (item.subject === 'Overall') {
                  if (item.score !== undefined) {
                    newOverall.overallScore = item.score;
                  }
                  if (item.remarks && item.remarks.includes('Position:')) {
                    newOverall.position = item.remarks.replace('Position:', '').trim();
                  }
                  [
                    'handwriting', 'punctuality', 'initiative', 'obedience', 'honesty',
                    'neatness', 'attentiveness', 'respect', 'attitude', 'creativity',
                    'teacherComment', 'signatureDate', 'headTeacherRemark', 'academicYear',
                    'schoolOpened', 'present', 'absent', 'totalScore', 'projectDefence',
                    'average', 'nextTerm'
                  ].forEach(field => {
                    if (item[field] !== undefined) {
                      newOverall[field] = item[field];
                    }
                  });
                }
              });
              return { ...prevOverall, [selectedStudent._id]: newOverall };
            });

            setCaScores(prevCaScores => {
              const prev = prevCaScores[selectedStudent._id] || {};
              const newCaScores = { ...prev };
              backendData.forEach(item => {
                if (item.subject && item.subject.endsWith('C/A') && item.score !== undefined) {
                  const caSubject = item.subject.replace(' C/A', '');
                  newCaScores[caSubject] = item.score;
                }
              });
              return { ...prevCaScores, [selectedStudent._id]: newCaScores };
            });
          })
          .catch(err => {
            console.error('[ERROR] Error fetching backend data for student:', err);
          });
      }
    }, [selectedStudent, teacherData, selectedTerm, subjects]);

    // 4. Save result data for selected student to localStorage (including subjects)
    useEffect(() => {
      if (selectedStudent) {
        localStorage.setItem(
          `resultPortal_${teacherData?.className}_${selectedTerm}_${selectedStudent._id}`,
          JSON.stringify({
            results: results[selectedStudent._id] || {},
            caScores: caScores[selectedStudent._id] || {},
            overall: overall[selectedStudent._id] || {},
            subjects,
          })
        );
      }
    }, [results, caScores, overall, subjects, selectedStudent, teacherData, selectedTerm]);

    // Get teacher data from localStorage
    useEffect(() => {
        const stored = localStorage.getItem('teacherData');
        if (stored) setTeacherData(JSON.parse(stored));
    }, []);

    // Fetch all students registered under this class and term
   useEffect(() => {
    const fetchStudents = async () => {
        setIsLoadingStudents(true);
        setStudents([]);
        if (teacherData?.className && selectedTerm) {
            try {
                const res = await fetch(
                    `${API_BASE_URL}/api/user/class/${encodeURIComponent(teacherData.className)}/${selectedTerm}/students`
                );
                if (!res.ok) throw new Error('Failed to fetch students');
                const data = await res.json();
                setStudents(Array.isArray(data) ? data : []);
            } catch (err) {
                setStudents([]);
            }
        }
        setIsLoadingStudents(false);
    };
    fetchStudents();
}, [teacherData, selectedTerm]);
    // Fetch teacher's results for the class and term
    useEffect(() => {
        if (teacherData?.className && selectedTerm) {
            setIsLoadingResults(true);
            console.log('Fetching results for class:', teacherData.className, 'term:', selectedTerm);
            fetch(`${API_BASE_URL}/api/results/class/${encodeURIComponent(teacherData.className)}/${encodeURIComponent(selectedTerm)}`, {
                credentials: 'include'
            })
                .then(res => {
                    console.log('Fetch response status:', res.status);
                    return res.json();
                })
                .then(data => {
                    console.log('Fetched data:', data);
                    setTeacherResults(Array.isArray(data) ? data : []);
                    // Merge previous state to preserve input
                    const newResults = { ...results };
                    const newCaScores = { ...caScores };
                    const newOverall = { ...overall };
                    students.forEach(student => {
                      console.log('Mapping for student:', student._id, student.name);
                      const studentData = data.filter(r => String(r.studentId) === String(student._id));
                      console.log('Student data:', studentData);
                      newResults[student._id] = { ...(results[student._id] || {}) };
                      newCaScores[student._id] = { ...(caScores[student._id] || {}) };
                      subjects.forEach(subject => {
                        // Find all result objects for this student/subject
                        const foundResults = data.filter(
                          r => String(r.studentId) === String(student._id) && r.subject === subject
                        );
                        console.log('Found results for subject:', subject, foundResults);
                        if (foundResults.length > 0) {
                          // Set all fields from backend for this subject
                          const r = foundResults[0];
                          const fieldMap = {
                            '_project': 'projectScore',
                            '_cat1': 'firstCatScore',
                            '_cat2': 'secondCatScore',
                            '_exam': 'examScore',
                            '_maxScore': 'maxScore',
                            '_minScore': 'minScore',
                            '_grade': 'grade',
                            '_remark': 'remark',
                            'overallScore': 'overallScore' // <-- add this line if you use fieldMap for mapping
                          };
                          [
                            '_project', '_cat1', '_cat2', '_exam', '_maxScore', '_minScore', '_grade', '_remark', 'overallScore'
                          ].forEach(suffix => {
                            const backendField = fieldMap[suffix];
                            if (r[backendField] !== undefined) {
                              newResults[student._id][subject + suffix] = r[backendField];
                              console.log('Set', subject + suffix, 'to', r[backendField]);
                            }
                          });
                          // Also set score if present
                          if (r.score !== undefined) {
                            newResults[student._id][subject] = r.score;
                            console.log('Set', subject, 'to', r.score);
                          }
                        }
                        // C/A scores
                        const foundCA = data.find(
                          r => String(r.studentId) === String(student._id) && r.subject === `${subject} C/A`
                        );
                        if (foundCA) {
                          newCaScores[student._id][subject] = foundCA.score;
                          console.log('Set CA for', subject, 'to', foundCA.score);
                        }
                      });
                      // Overall
                      const foundOverall = data.find(
                        r => String(r.studentId) === String(student._id) && r.subject === 'Overall'
                      );
                      if (foundOverall) {
                        console.log('Found overall:', foundOverall);
                        newOverall[student._id] = {
                          ...(overall[student._id] || {}),
                          overallScore: foundOverall.overallScore || foundOverall.score,
                          position: foundOverall.remarks?.replace('Position:', '').trim() || ''
                        };
                        console.log('Set overall for student:', student._id, newOverall[student._id]);
                      }
                    });
                    console.log('Final newResults:', newResults);
                    setResults(newResults);
                    setCaScores(newCaScores);
                    setOverall(newOverall);
                })
                .catch(err => {
                    console.log('Error fetching results:', err);
                    setTeacherResults([]);
                    // Do NOT reset results, caScores, or overall here!
                })
                .finally(() => setIsLoadingResults(false));
        }
    }, [teacherData, selectedTerm, students, subjects]);

    // Map fetched results to local state
    useEffect(() => {
    if (teacherResults.length && students.length && subjects.length) {
        // Merge previous state to preserve input
        const newResults = { ...results };
        const newCaScores = { ...caScores };
        students.forEach(student => {
            newResults[student._id] = { ...(results[student._id] || {}) };
            newCaScores[student._id] = { ...(caScores[student._id] || {}) };
            subjects.forEach(subject => {
                // Only update if found in teacherResults, otherwise preserve previous value
                const foundExam = teacherResults.find(
                    r => String(r.studentId) === String(student._id) && r.subject === subject
                );
                if (foundExam) {
                    // Map subject fields
                    [
                        '_project',
                        '_cat1',
                        '_cat2',
                        '_exam',
                        '_maxScore',
                        '_minScore',
                        '_grade',
                        '_remark',
                        '_overallScore'
                    ].forEach(suffix => {
                        const key = `${subject}${suffix}`;
                        if (foundExam[suffix.replace('_', '')] !== undefined) {
                            newResults[student._id][key] = foundExam[suffix.replace('_', '')];
                        }
                    });
                    // Main subject score (total)
                    if (foundExam.score !== undefined) {
                        newResults[student._id][subject] = foundExam.score;
                    }
                }
                const foundCA = teacherResults.find(
                    r => r.studentId?.toString() === student._id && r.subject === `${subject} C/A`
                );
                if (foundCA && foundCA.score !== undefined) {
                    newCaScores[student._id][subject] = foundCA.score;
                }
            });

            // --- Add this block to map key rating and meta fields ---
            const foundMeta = teacherResults.find(
                r => String(r.studentId) === String(student._id) && r.subject === 'Overall'
            );
            if (foundMeta) {
                [
                    'handwriting', 'punctuality', 'initiative', 'obedience', 'honesty',
                    'neatness', 'attentiveness', 'respect', 'attitude', 'creativity',
                    'teacherComment', 'signatureDate', 'headTeacherRemark', 'academicYear',
                    'schoolOpened', 'present', 'absent', 'totalScore', 'projectDefence',
                    'average', 'nextTerm', 'overallScore'
                ].forEach(field => {
                    if (foundMeta[field] !== undefined) {
                        newResults[student._id][field] = foundMeta[field];
                    }
                });
                // --- Ensure overallScore is set in results for UI binding ---
                if (foundMeta.score !== undefined) {
                    newResults[student._id].overallScore = foundMeta.score;
                }
            }
            // --- End block ---
        });
        setResults(newResults);
        setCaScores(newCaScores);

        // Merge overall state
        const newOverall = { ...overall };
        students.forEach(student => {
            const found = teacherResults.find(
                r => r.studentId?.toString() === student._id && r.subject === 'Overall'
            );
            if (found) {
                newOverall[student._id] = {
                    ...(overall[student._id] || {}),
                    overallScore: found.score,
                    position: found.remarks?.replace('Position:', '').trim() || ''
                };
                // --- Ensure overallScore is also in results for UI binding ---
                if (!newResults[student._id]) newResults[student._id] = {};
                newResults[student._id].overallScore = found.score;
            }
        });
        setOverall(newOverall);
    }
}, [teacherResults, students, subjects]);


    // --- ADDED: Track pushed status for each student ---
    useEffect(() => {
      if (students.length && teacherData?.className && selectedTerm) {
        const fetchPushedStatus = async () => {
          const pushedStatus = {};
          for (const student of students) {
            try {
              const res = await fetch(
                `${API_BASE_URL}/api/results/student/${student._id}/pushed?className=${encodeURIComponent(teacherData.className)}&term=${encodeURIComponent(selectedTerm)}`
              );
              const pushedResults = await res.json();
              pushedStatus[student._id] = Array.isArray(pushedResults) && pushedResults.length > 0;
            } catch {
              pushedStatus[student._id] = false;
            }
          }
          setResultsPushed(prev => ({ ...prev, ...pushedStatus }));
        };
        fetchPushedStatus();
      }
    }, [students, teacherData, selectedTerm]);
    // --- END ADDED ---

    // --- ADDED: Track verified status for each student ---
    useEffect(() => {
      if (teacherResults.length && students.length) {
        const verifiedStatus = {};
        students.forEach(student => {
          const isVerified = teacherResults.some(
            r => String(r.studentId) === String(student._id) && r.verified === true && r.pending === false
          );
          verifiedStatus[student._id] = isVerified;
        });
        setResultsPushed(prev => {
          const updated = { ...prev };
          Object.keys(verifiedStatus).forEach(id => {
            if (verifiedStatus[id]) updated[id] = true;
          });
          return updated;
        });
      }
    }, [teacherResults, students]);

    function isSubjectFilled(studentId, subject) {
  const subjectFields = [
    `${subject}_project`,
    `${subject}_cat1`,
    `${subject}_cat2`,
    `${subject}_exam`,
    `${subject}_maxScore`,
    `${subject}_minScore`,
    `${subject}_grade`,
    `${subject}_remark`,
    `${subject}_overallScore`
  ];
  return subjectFields.some(
    field => results?.[studentId]?.[field] !== undefined && results?.[studentId]?.[field] !== ''
  );
}
    // --- END ADDED ---

    // Automatically update overall score and position when subject scores change, unless manually edited
    useEffect(() => {
  if (students.length && subjects.length) {
    // 1. Calculate each student's total C.A.T + Exam for all their subjects
    const studentTotals = students.map(student => {
      const studentId = student._id;
      let totalScore = 0;
      let subjectCount = 0;
      subjects.forEach(subject => {
        const cat = Number(results?.[studentId]?.[`${subject}_cat1`] || 0);
        const exam = Number(results?.[studentId]?.[`${subject}_exam`] || 0);
        // Only count if at least one score is entered (prevents division by zero)
        if (cat !== 0 || exam !== 0) {
          totalScore += cat + exam;
          subjectCount += 1;
        }
      });
      // If no subjects have scores, subjectCount fallback to subjects.length
      if (subjectCount === 0) subjectCount = subjects.length;
      // Calculate average, clamp to 100
      let average = subjectCount > 0 ? totalScore / subjectCount : 0;
      if (average > 100) average = 100;
      return {
        studentId,
        totalScore,
        average: Number(average.toFixed(1)),
      };
    });

    // 2. Sort by average DESC for position
    const sorted = [...studentTotals].sort((a, b) => b.average - a.average);

    // 3. Assign positions (handle ties)
    const positionMap = {};
    let lastAverage = null;
    let lastPosition = 0;
    let actualPosition = 1;
    sorted.forEach(item => {
      if (lastAverage !== null && item.average === lastAverage) {
        positionMap[item.studentId] = lastPosition;
      } else {
        positionMap[item.studentId] = actualPosition;
        lastAverage = item.average;
        lastPosition = actualPosition;
      }
      actualPosition++;
    });

    // 4. Update overall state for each student
    const newOverall = { ...overall };
    students.forEach(student => {
      const studentId = student._id;
      const studentData = studentTotals.find(s => s.studentId === studentId);
      const autoAverage = studentData?.average || 0;
      const autoPosition = positionMap[studentId];
      // Only update if not manually edited
      if (!manualOverall[studentId]) {
        newOverall[studentId] = {
          ...(newOverall[studentId] || {}),
          overallScore: autoAverage,
          position: autoPosition
            ? `${autoPosition}${autoPosition === 1 ? 'st' : autoPosition === 2 ? 'nd' : autoPosition === 3 ? 'rd' : 'th'}`
            : '',
        };
      }
      // Always update the average field in results for UI binding
      setResults(prev => ({
        ...prev,
        [studentId]: {
          ...(prev[studentId] || {}),
          average: autoAverage,
        },
      }));
    });
    setOverall(newOverall);
  }
  // eslint-disable-next-line
}, [results, caScores, students, subjects]);

// Add this useEffect to fetch subjects from backend
useEffect(() => {
  if (teacherData?.className && selectedTerm) {
    fetch(`${API_BASE_URL}/api/class-subjects/${encodeURIComponent(teacherData.className)}?term=${encodeURIComponent(selectedTerm)}`)
      .then(res => res.json())
      .then(subjects => {
        setSubjects(Array.isArray(subjects) ? subjects : []);
      });
  }
}, [teacherData, selectedTerm]);

const handleAddSubject = async () => {
  const subject = newSubject.trim();
  if (subject && !subjects.includes(subject)) {
    const updatedSubjects = [...subjects, subject];
    // Update backend
    await fetch(`${API_BASE_URL}/api/class-subjects/set`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        className: teacherData.className,
        term: selectedTerm,
        subjects: updatedSubjects
      }),
    });
    setNewSubject('');
    // Refetch subjects from backend
    fetch(`${API_BASE_URL}/api/class-subjects/${encodeURIComponent(teacherData.className)}?term=${encodeURIComponent(selectedTerm)}`)
      .then(res => res.json())
      .then(subjects => {
        setSubjects(Array.isArray(subjects) ? subjects : []);
      });
  }
};


// Remove subject from tray
// ...existing code...
const handleRemoveSubject = async (subject) => {
  const updatedSubjects = subjects.filter(s => s !== subject);
  // Update backend
  await fetch(`${API_BASE_URL}/api/class-subjects/set`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      className: teacherData.className,
      term: selectedTerm,
      subjects: updatedSubjects
    }),
  });
  // Refetch subjects from backend
  fetch(`${API_BASE_URL}/api/class-subjects/${encodeURIComponent(teacherData.className)}?term=${encodeURIComponent(selectedTerm)}`)
    .then(res => res.json())
    .then(subjects => {
      setSubjects(Array.isArray(subjects) ? subjects : []);
    });
};
// ...existing code...



    const keyRatingFields = [
      'handwriting', 'punctuality', 'initiative', 'obedience', 'honesty',
      'neatness', 'attentiveness', 'respect', 'attitude', 'creativity'
    ];

    // Handle result input change
    const handleResultChange = (studentId, field, value) => {
      setDirtyStudents(prev => ({ ...prev, [studentId]: true }));

      setResults(prev => {
        const updated = {
          ...prev,
          [studentId]: {
            ...(prev[studentId] || {}),
            [field]: value
          }
        };

        // Auto-calculate total, grade, and remark for the subject if any score field changes
        const [subject, part] = field.split('_');
        if (subjects.includes(subject)) {
          const cat1 = Number(updated[studentId][`${subject}_cat1`] || 0);
          const exam = Number(updated[studentId][`${subject}_exam`] || 0);
          const total = cat1 + exam;

          // Only auto-fill if user hasn't manually set total/grade/remark
          if (!updated[studentId][`${subject}_total_manual`]) {
            updated[studentId][`${subject}_total`] = total;
          }
          if (!updated[studentId][`${subject}_grade_manual`]) {
            updated[studentId][`${subject}_grade`] = getGrade(total);
          }
          if (!updated[studentId][`${subject}_remark_manual`]) {
            updated[studentId][`${subject}_remark`] = getRemark(getGrade(total));
          }
        }
        return updated;
      });
    };

    // Handle overall score and position change (manual edit)
    const handleOverallChange = (studentId, field, value) => {
        setOverall(prev => ({
            ...prev,
            [studentId]: {
                ...(prev[studentId] || {}),
                [field]: value
            }
        }));
        if (field === 'overallScore') {
            setManualOverall(prev => ({ ...prev, [studentId]: true }));
        }
    };

    // Submit results for all students
    const handleSubmitResults = async () => {
  setIsSubmitting(true);
  setSuccessMsg('');
  setErrorMsg('');
  let allSuccess = true;
  let failedStudents = [];
  let emptySubjects = [];

  try {
    for (const student of students) {
      // Always use buildSaveAllPayload to include average, C.A.T, Exam, etc.
      const savePayload = buildSaveAllPayload(student._id, false); // isPush: false for save
      const res = await fetch(`${API_BASE_URL}/api/results/save-all`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(savePayload),
      });
      if (!res.ok) {
        allSuccess = false;
        failedStudents.push(student.name);
      }
    }
    if (allSuccess) {
      setSuccessMsg('Results have been successfully saved for all students.');
    } else {
      setErrorMsg(`Failed to save results for: ${failedStudents.join(', ')}. Please try again.`);
    }
  } catch (err) {
    setErrorMsg('Failed to save results. Please try again.');
  }
  setIsSubmitting(false);
};

// Push individual student result
const handlePushIndividualResult = async (studentId) => {
  if (resultsPushed[studentId]) return; // Prevent double push
  setIsSubmitting(true);
  setSuccessMsg('');
  setErrorMsg('');
  let success = true;
  try {
    // Always use buildSaveAllPayload to include average, C.A.T, Exam, etc.
    const savePayload = buildSaveAllPayload(studentId, true); // isPush: true for push
    const saveRes = await fetch(`${API_BASE_URL}/api/results/save-all`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(savePayload),
    });
    if (!saveRes.ok) {
      throw new Error('Failed to save data before pushing');
    }

    for (const subject of subjects) {
      const score = results?.[studentId]?.[subject];
      if (score !== undefined && score !== '') {
        await fetch(`${API_BASE_URL}/api/results/set`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            studentId,
            teacherId: teacherData._id,
            className: teacherData.className,
            term: selectedTerm,
            subject,
            score: Number(score) || 0,
            isPush: true // Always true for push
          })
        });
      }

      const caScore = caScores?.[studentId]?.[subject];
      if (caScore !== undefined && caScore !== '') {
        await fetch(`${API_BASE_URL}/api/results/set`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            studentId,
            teacherId: teacherData._id,
            className: teacherData.className,
            term: selectedTerm,
            subject: `${subject} C/A`,
            score: Number(caScore) || 0,
            isPush: true // Always true for push
          })
        });
      }
    }
    const overallScore = overall?.[studentId]?.overallScore;
    const position = overall?.[studentId]?.position;
    if (overallScore || position) {
      const res = await fetch(`${API_BASE_URL}/api/results/set`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId,
          teacherId: teacherData._id,
          className: teacherData.className,
          term: selectedTerm,
          subject: 'Overall',
          score: Number(overallScore) || 0,
          remarks: `Position: ${position || ''}`,
          isPush: true // Always true for push
        })
      });
      if (!res.ok) {
        success = false;
      }
    }
    if (success) {
      setResultsPushed(prev => ({ ...prev, [studentId]: true }));
      setSuccessMsg('Student result has been successfully pushed.');
      // Update localStorage with current state after push (retains data even if pushed)
      localStorage.setItem(
        `resultPortal_${teacherData.className}_${selectedTerm}_${studentId}`,
        JSON.stringify({
          results: results[studentId] || {},
          caScores: caScores[studentId] || {},
          overall: overall[studentId] || {},
          subjects,
        })
      );
      // Clear dirty flag
      setDirtyStudents(prev => ({ ...prev, [studentId]: false }));
      setIsLoadingResults(true); // Show spinner while fetching
      fetch(`${API_BASE_URL}/api/results/class/${encodeURIComponent(teacherData.className)}/${encodeURIComponent(selectedTerm)}`, {
        credentials: 'include'
      })
        .then(res => res.json())
        .then(data => {
          setTeacherResults(Array.isArray(data) ? data : []);
        })
        .finally(() => setIsLoadingResults(false));

            // --- Re-fetch pushed status for the student (only confirm, never undo) ---
      fetch(`${API_BASE_URL}/api/results/student/${studentId}/pushed?className=${encodeURIComponent(teacherData.className)}&term=${encodeURIComponent(selectedTerm)}`, {
        credentials: 'include'
      })
        .then(res => res.json())
        .then(pushedResults => {
          if (Array.isArray(pushedResults) && pushedResults.length > 0) {
            setResultsPushed(prev => ({
              ...prev,
              [studentId]: true
            }));
          }
          // Do NOT set to false here — the optimistic true from line 937 should stick
        });
      // --- END ADD ---
    } else {
      setErrorMsg('Failed to update student result. Please try again.');
    }
  } catch (err) {
    setErrorMsg('Failed to update student result. Please try again.');
  }
  setIsSubmitting(false);
  setShowPushConfirm(false);
  setPendingPushStudentId(null);
};
const handleGeneralPush = async () => {
  setIsGeneralPushing(true);
  setSuccessMsg('');
  setErrorMsg('');
  let allSuccess = true;
  let failedStudents = [];

  for (const student of students) {
    if (resultsPushed[student._id]) continue; // Skip already pushed
    try {
      await handlePushIndividualResult(student._id);
    } catch {
      allSuccess = false;
      failedStudents.push(student.name);
    }
  }

  if (allSuccess) {
    setSuccessMsg('All student results have been successfully pushed.');
  } else {
    setErrorMsg(`Failed to push results for: ${failedStudents.join(', ')}. Please try again.`);
  }
  setIsGeneralPushing(false);
};
// Load saved result data for selected student
   // 3. Load subjects from localStorage for selected student
useEffect(() => {
  if (selectedStudent) {
    const key = `resultPortal_${teacherData?.className}_${selectedTerm}_${selectedStudent._id}`;
    const saved = localStorage.getItem(key);
    if (saved) {
      const parsed = JSON.parse(saved);
      // Merge subjects from localStorage for this student
      if (Array.isArray(parsed.subjects) && parsed.subjects.length > 0) {
        setSubjects(prev => {
          const merged = Array.from(new Set([...prev, ...parsed.subjects]));
          return merged;
        });
      }
    }
  }
}, [selectedStudent, teacherData, selectedTerm]);

    // Save result data for selected student to localStorage
    useEffect(() => {
      if (selectedStudent) {
        localStorage.setItem(
          `resultPortal_${teacherData?.className}_${selectedTerm}_${selectedStudent._id}`,
          JSON.stringify({
            results: results[selectedStudent._id] || {},
            caScores: caScores[selectedStudent._id] || {},
            overall: overall[selectedStudent._id] || {},
            subjects,
          })
        );
      }
    }, [results, caScores, overall, subjects, selectedStudent, teacherData, selectedTerm]);

    // Autosave result data for selected student to backend (debounced)
    useEffect(() => {
      if (selectedStudent && !resultsPushed[selectedStudent._id]) {
        const timeout = setTimeout(() => {
          const payload = {
            studentId: selectedStudent._id,
            teacherId: teacherData?._id,
            className: teacherData?.className,
            term: selectedTerm,
            subjects,
            caScores: caScores[selectedStudent._id] || {},
            ...results[selectedStudent._id],
            ...overall[selectedStudent._id],
          };
          // Only autosave if there is some data to save
          if (
            Object.keys(results[selectedStudent._id] || {}).length > 0 ||
            Object.keys(caScores[selectedStudent._id] || {}).length > 0 ||
            Object.keys(overall[selectedStudent._id] || {}).length > 0
          ) {
            fetch(`${API_BASE_URL}/api/results/save-all`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(payload),
            });
          }
        }, 7000); // 7 seconds debounce

        return () => clearTimeout(timeout);
      }
    }, [results, caScores, overall, subjects, selectedStudent, teacherData, selectedTerm, resultsPushed]);

    // Add this helper function near the top of your file
function isValidObjectId(id) {
  return typeof id === 'string' && id.length === 24 && /^[a-fA-F0-9]+$/.test(id);
}

// --- REPLACE THIS BLOCK WITH THE NEW MERGE LOGIC ---
useEffect(() => {
  if (
    selectedStudent &&
    teacherData?.className &&
    selectedTerm &&
    isValidObjectId(selectedStudent._id)
  ) {
    fetch(
      `${API_BASE_URL}/api/results/student/${selectedStudent._id}/all?className=${teacherData.className}&term=${selectedTerm}`
    )
      .then(res => res.json())
      .then(backendData => {
        if (!backendData || backendData.length === 0) return;

        // --- Collect all subjects from backend ---
        const backendSubjects = backendData
          .filter(item => item.subject && item.subject !== 'Overall' && !item.subject.endsWith('C/A'))
          .map(item => item.subject);

        // --- Load subjects from localStorage for this student ---
        let localSubjects = [];
        try {
          const key = `resultPortal_${teacherData?.className}_${selectedTerm}_${selectedStudent._id}`;
          const saved = localStorage.getItem(key);
          if (saved) {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed.subjects)) {
              localSubjects = parsed.subjects;
            }
          }
        } catch {}

        // --- Merge backend, localStorage, and current subjects ---
       setSubjects(prevSubjects => {
  // Only keep subjects that are not deleted
  const merged = Array.from(new Set([
    ...(prevSubjects || []).filter(s => backendSubjects.includes(s)),
    ...backendSubjects
  ]));
  return merged;
});

        // Prepare new state objects, always merge with previous state
        setResults(prevResults => {
          const prev = prevResults[selectedStudent._id] || {};
          const newResults = { ...prev };
          backendData.forEach(item => {
            if (item.subject && item.subject !== 'Overall') {
              [
                '_project',
                '_cat1',
                '_cat2',
                '_exam',
                '_maxScore',
                '_minScore',
                '_grade',
                '_remark',
                '_overallScore'
              ].forEach(suffix => {
                const key = `${item.subject}${suffix}`;
                if (item[suffix.replace('_', '')] !== undefined) {
                  newResults[key] = item[suffix.replace('_', '')];
                }
              });
              if (item.score !== undefined) {
                newResults[item.subject] = item.score;
              }
              if (item.subject.endsWith('C/A') && item.score !== undefined) {
                // handled in caScores below
              }
            }
            [
              'handwriting', 'punctuality', 'initiative', 'obedience', 'honesty',
              'neatness', 'attentiveness', 'respect', 'attitude', 'creativity'
            ].forEach(field => {
              if (item[field] !== undefined) {
                newResults[field] = item[field];
              }
            });
            if (item.teacherComment !== undefined) newResults.teacherComment = item.teacherComment;
            if (item.signatureDate !== undefined) newResults.signatureDate = item.signatureDate;
            if (item.headTeacherRemark !== undefined) newResults.headTeacherRemark = item.headTeacherRemark;
            if (item.academicYear !== undefined) newResults.academicYear = item.academicYear;
            if (item.schoolOpened !== undefined) newResults.schoolOpened = item.schoolOpened;
            if (item.present !== undefined) newResults.present = item.present;
            if (item.absent !== undefined) newResults.absent = item.absent;
            if (item.totalScore !== undefined) newResults.totalScore = item.totalScore;
            if (item.projectDefence !== undefined) newResults.projectDefence = item.projectDefence;
            if (item.average !== undefined) newResults.average = item.average;
            if (item.nextTerm !== undefined) newResults.nextTerm = item.nextTerm;
            if (item.subject === 'Overall') {
              if (item.score !== undefined) {
                newResults.overallScore = item.score;
              }
              if (item.remarks && item.remarks.includes('Position:')) {
                newResults.position = item.remarks.replace('Position:', '').trim();
              }
            }
          });
          // Filter out removed subjects
          const validSubjects = new Set(subjects);
          const filteredResults = {};
          Object.entries(newResults).forEach(([key, value]) => {
            const match = key.match(/^(.+?)_/);
            if (match) {
              const subj = match[1];
              if (validSubjects.has(subj)) {
                filteredResults[key] = value;
              }
            } else if (validSubjects.has(key) || !key.includes('_')) {
              filteredResults[key] = value;
            }
          });
          return { ...prevResults, [selectedStudent._id]: filteredResults };
        });

        setOverall(prevOverall => {
          const prev = prevOverall[selectedStudent._id] || {};
          const newOverall = { ...prev };
          backendData.forEach(item => {
            if (item.subject === 'Overall') {
              if (item.score !== undefined) {
                newOverall.overallScore = item.score;
              }
              if (item.remarks && item.remarks.includes('Position:')) {
                newOverall.position = item.remarks.replace('Position:', '').trim();
              }
              [
                'handwriting', 'punctuality', 'initiative', 'obedience', 'honesty',
                'neatness', 'attentiveness', 'respect', 'attitude', 'creativity',
                'teacherComment', 'signatureDate', 'headTeacherRemark', 'academicYear',
                'schoolOpened', 'present', 'absent', 'totalScore', 'projectDefence',
                'average', 'nextTerm'
              ].forEach(field => {
                if (item[field] !== undefined) {
                  newOverall[field] = item[field];
                }
              });
            }
          });
          return { ...prevOverall, [selectedStudent._id]: newOverall };
        });

        setCaScores(prevCaScores => {
          const prev = prevCaScores[selectedStudent._id] || {};
          const newCaScores = { ...prev };
          backendData.forEach(item => {
            if (item.subject && item.subject.endsWith('C/A') && item.score !== undefined) {
              const caSubject = item.subject.replace(' C/A', '');
              newCaScores[caSubject] = item.score;
            }
          });
          return { ...prevCaScores, [selectedStudent._id]: newCaScores };
        });
      })
      .catch(err => {
        console.error('[ERROR] Error fetching backend data for student:', err);
      });
  }
}, [selectedStudent, teacherData, selectedTerm, subjects]);
// --- END REPLACE ---

    // Term selection before entering main page
    if (!selectedTerm) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-background">
                <div className="bg-card border border-border rounded-xl shadow-lg p-8 w-full max-w-md text-center">
                    <h2 className="font-heading text-2xl font-bold text-primary mb-4">Select Term</h2>
                    <select
                        className="w-full border rounded-lg px-3 py-2 mb-6 focus:outline-none focus:ring"
                        value={selectedTerm}
                        onChange={e => setSelectedTerm(e.target.value)}
                    >
                        <option value="">Choose a term</option>
                        {terms.map(term => (
                            <option key={term.value} value={term.value}>{term.label}</option>
                        ))}
                    </select>
                    <Button
                        variant="default"
                        disabled={!selectedTerm}
                        onClick={() => {}}
                        className="w-full"
                    >
                        <Icon name="ArrowRight" size={16} className="mr-2" />
                        Proceed
                    </Button>
                </div>
            </div>
        );
    }

    // If a student is selected, show the result entry page for that student
    if (selectedStudent) {
        // Only set read-only if result has been pushed (not after save)
        const isReadOnly = resultsPushed[selectedStudent._id] === true;

        // --- Position Calculation ---
    // Get all students' overall scores for this class/term
    const studentScores = students.map(s => {
      const overallScore = Number(overall[s._id]?.overallScore) || 0;
      // If you want to use average as a tiebreaker, get it here:
      const average = Number(results?.[s._id]?.average) || 0;
      return {
        _id: s._id,
        name: s.name,
        overallScore,
        average
      };
    });

    // Sort by overallScore DESC, then by average DESC
    studentScores.sort((a, b) => {
      if (b.overallScore !== a.overallScore) return b.overallScore - a.overallScore;
      return b.average - a.average;
    });

    // Assign positions (1st, 2nd, 3rd, 4th, ...), handling ties
    let lastScore = null;
    let lastAverage = null;
    let lastPosition = 0;
    let actualPosition = 1;
    const positions = {};
    studentScores.forEach((s, idx) => {
      if (
        s.overallScore === lastScore &&
        s.average === lastAverage
      ) {
        positions[s._id] = lastPosition; // Same score & average, same position
      } else {
        positions[s._id] = actualPosition;
        lastScore = s.overallScore;
        lastAverage = s.average;
        lastPosition = actualPosition;
      }
      actualPosition++;
    });

    // Get the auto-calculated position for the selected student
    const autoPosition = positions[selectedStudent._id] || '';

    // Use manual position if set, otherwise use auto
    const manualPosition = overall[selectedStudent._id]?.position;
    const positionValue =
      manualPosition !== undefined && manualPosition !== null && manualPosition !== ''
        ? manualPosition
        : autoPosition
          ? `${autoPosition}${autoPosition === 1 ? 'st' : autoPosition === 2 ? 'nd' : autoPosition === 3 ? 'rd' : 'th'}`
          : '';

        return (
            <main className="pt-20 pb-10 bg-background min-h-screen">
          <div className="max-w-3xl mx-auto px-2 sm:px-4">
            <Button variant="outline" onClick={() => setSelectedStudent(null)} className="mb-4">
              <Icon name="ArrowLeft" size={16} className="mr-2" />
              Back to Student List
            </Button>
            <h2 className="font-heading text-2xl font-bold text-primary mb-2">
              Enter Result for {selectedStudent.name}
            </h2>
            <div className="bg-card border border-border rounded-xl shadow-lg p-6">
              {/* Feedback message area */}
              {(successMsg || errorMsg) && (
                <div
                  className={`mb-4 px-4 py-2 rounded-lg font-medium text-center transition-all ${
                    successMsg
                      ? 'bg-green-100 text-green-700 border border-green-300'
                      : 'bg-red-100 text-red-700 border border-red-300'
                  }`}
                >
                  {successMsg || errorMsg}
                  <button
                    className="ml-2 text-xs text-gray-500 hover:text-gray-700"
                    onClick={() => {
                      setSuccessMsg('');
                      setErrorMsg('');
                    }}
                    aria-label="Dismiss"
                  >
                    &times;
                  </button>
                </div>
              )}
              {/* --- Position and Average Box Fields --- */}
              <div className="mb-4 flex flex-wrap gap-4 items-center">
  <div>
    <label className="font-semibold">Position:</label>
    <input
      type="text"
      className="border rounded px-2 py-1 w-24 ml-2"
      value={positionValue}
      readOnly={isReadOnly}
      onChange={e =>
        handleOverallChange(selectedStudent._id, 'position', e.target.value)
      }
      title={
        manualPosition
          ? "Manually set. Clear to use auto-calculated position."
          : "Auto-calculated. You can override by typing."
      }
    />
    <small className="text-xs text-gray-500 ml-2">
      {manualPosition ? "Manual" : "Auto"}
    </small>
  </div>
  <div>
    <label className="font-semibold">Average:</label>
    {(() => {
      // Calculate average of subject totals
      const subjectTotals = subjects.map(subject => {
        const cat1 = Number(results?.[selectedStudent._id]?.[`${subject}_cat1`] || 0);
        const exam = Number(results?.[selectedStudent._id]?.[`${subject}_exam`] || 0);
        return cat1 + exam;
      });
      let autoAverage =
        subjectTotals.length > 0
          ? (subjectTotals.reduce((a, b) => a + b, 0) / subjectTotals.length)
          : '';
      // Clamp to 100
      if (autoAverage !== '' && autoAverage > 100) autoAverage = 100;
      autoAverage = autoAverage !== '' ? Number(autoAverage).toFixed(1) : '';
      // Use manual value if set, else auto
      const manualAverage = results?.[selectedStudent._id]?.average;
      const displayAverage =
        manualAverage !== undefined && manualAverage !== null && manualAverage !== ''
          ? manualAverage
          : autoAverage;
      return (
        <input
          type="number"
          step="0.1"
          className="border rounded px-2 py-1 w-24 ml-2"
          value={displayAverage}
          onChange={e => handleResultChange(selectedStudent._id, 'average', e.target.value)}
          placeholder="Average"
          readOnly={isReadOnly}
          max={100}
          title={
            manualAverage !== undefined && manualAverage !== null && manualAverage !== ''
              ? 'Manual'
              : 'Auto-calculated'
          }
        />
      );
    })()}
  </div>
</div>
              <form
                onSubmit={e => {
                  e.preventDefault();
                  if (!isReadOnly) handlePushIndividualResult(selectedStudent._id);
                }}
              >
                <div className="overflow-x-auto">
                  <table className="min-w-full border-collapse mb-6">
                    <thead>
                      <tr>
                        <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Subject</th>
                        <th className="px-2 py-2 text-left font-semibold text-muted-foreground">C.A.T (30%)</th>
                        <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Exam (70%)</th>
                        <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Total (100%)</th>
                        {/* Removed Max Score */}
                        {/* Removed Min Score */}
                        <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Grade</th>
                        <th className="px-2 py-2 text-left font-semibold text-muted-foreground">Remark</th>
                      </tr>
                    </thead>
                    <tbody>
                      {subjects.map(subject => {
                        // Only one C.A.T (cat1, 30) and Exam (70)
                        const cat1 = Number(results?.[selectedStudent._id]?.[`${subject}_cat1`] || 0);
                        const exam = Number(results?.[selectedStudent._id]?.[`${subject}_exam`] || 0);
                        const total = cat1 + exam;

                        return (
                          <tr key={subject}>
                            <td className="px-2 py-2">{subject}</td>
                            {/* Only one C.A.T */}
                            <td className="px-2 py-2">
                              <input
                                type="number"
                                min="0"
                                max="30"
                                className="w-16 border rounded-lg px-2 py-1"
                                value={results?.[selectedStudent._id]?.[`${subject}_cat1`] || ''}
                                onChange={e => !isReadOnly && handleResultChange(selectedStudent._id, `${subject}_cat1`, e.target.value)}
                                placeholder="C.A.T"
                                readOnly={isReadOnly}
                              />
                            </td>
                            {/* Exam */}
                            <td className="px-2 py-2">
                              <input
                                type="number"
                                min="0"
                                max="70"
                                className="w-16 border rounded-lg px-2 py-1"
                                value={results?.[selectedStudent._id]?.[`${subject}_exam`] || ''}
                                onChange={e => !isReadOnly && handleResultChange(selectedStudent._id, `${subject}_exam`, e.target.value)}
                                placeholder="Exam"
                                readOnly={isReadOnly}
                              />
                            </td>
                            {/* Total */}
                            <td className="px-2 py-2 font-bold text-primary">
                              {total}
                            </td>
                            {/* Removed Max Score */}
                            {/* Removed Min Score */}
                            {/* Grade */}
                            <td className="px-2 py-2">
                              <input
                                type="text"
                                className="w-16 border rounded-lg px-2 py-1"
                                value={results?.[selectedStudent._id]?.[`${subject}_grade`] || ''}
                                onChange={e => {
                                  handleResultChange(selectedStudent._id, `${subject}_grade`, e.target.value);
                                  setResults(prev => ({
                                    ...prev,
                                    [selectedStudent._id]: {
                                      ...(prev[selectedStudent._id] || {}),
                                      [`${subject}_grade_manual`]: true
                                    }
                                  }));
                                }}
                                placeholder="Grade"
                                readOnly={isReadOnly}
                              />
                            </td>
                            {/* Remark */}
                            <td className="px-2 py-2">
                              <input
                                type="text"
                                className="w-24 border rounded-lg px-2 py-1"
                                value={results?.[selectedStudent._id]?.[`${subject}_remark`] || ''}
                                onChange={e => {
                                  handleResultChange(selectedStudent._id, `${subject}_remark`, e.target.value);
                                  setResults(prev => ({
                                    ...prev,
                                    [selectedStudent._id]: {
                                      ...(prev[selectedStudent._id] || {}),
                                      [`${subject}_remark_manual`]: true
                                    }
                                  }));
                                }}
                                placeholder="Remark"
                                readOnly={isReadOnly}
                              />
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                {/* Subject Tray (Add/Remove Subjects) */}
                <div className="mb-6">
                  <h4 className="font-semibold mb-2">Subjects</h4>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {subjects.map(subject => (
                      <span key={subject} className="flex items-center bg-gray-100 border border-gray-300 rounded px-3 py-1 text-sm font-medium">
                        {subject}
                        <button
                          type="button"
                          className="ml-2 text-red-500 hover:text-red-700"
                          onClick={() => setShowDeleteSubjectConfirm(subject)}
                          title="Remove subject"
                          disabled={isReadOnly}
                          style={isReadOnly ? { cursor: 'not-allowed', opacity: 0.5 } : {}}
                        >
                          &times;
                        </button>
                      </span>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      className="border rounded px-2 py-1 w-40"
                      value={newSubject}
                      onChange={e => setNewSubject(e.target.value)}
                      placeholder="Add subject"
                      disabled={isReadOnly} // <-- Disable input
                    />
                    <Button
                      variant="default"
                      type="button"
                      onClick={handleAddSubject}
                      disabled={!newSubject.trim() || isReadOnly} // <-- Disable add button
                    >
                      Add
                    </Button>
                  </div>
                </div>

                {/* Key Rating Section - Responsive & Professional */}
                <div className="mb-4">
                  <h4 className="font-semibold mb-2">Key Rating</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
                    {[
                      'handwriting', 'punctuality', 'initiative', 'obedience', 'honesty',
                      'neatness', 'attentiveness', 'respect', 'attitude', 'creativity'
                    ].map(key => (
                      <div key={key} className="flex flex-col items-start bg-gray-50 border border-gray-200 rounded-lg p-2">
                        <label className="text-sm font-medium capitalize mb-1">{key}</label>
                        <select
                          className="border rounded px-2 py-1 w-full"
                          value={results?.[selectedStudent._id]?.[key] || ''}
                          onChange={e => !isReadOnly && handleResultChange(selectedStudent._id, key, e.target.value)}
                          disabled={isReadOnly} // <-- add this
                        >
                          <option value="">Not marked</option>
                          <option value="5">5-Excellent</option>
                          <option value="4">4-Very Good</option>
                          <option value="3">3-Satisfactory</option>
                          <option value="2">2-Poor</option>
                          <option value="1">1-Very Poor</option>
                        </select>
                      </div>
                    ))}
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2 text-xs text-muted-foreground">
                    <span>5-EXCELLENT</span>
                    <span>4-VERY GOOD</span>
                    <span>3-SATISFACTORY</span>
                    <span>2-POOR</span>
                    <span>1-VERY POOR</span>
                  </div>
                </div>

                {/* Teacher's Comment, Signature, Head Teacher's Remark */}
                <div className="mb-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="font-semibold">Deans Remark:</label>
                    <textarea
                      className="border rounded px-2 py-1 w-full"
                      rows={2}
                      value="Good performance push harder"
                      readOnly
                      disabled
                      placeholder="Deans Remark"
                    />
                  </div>
                  <div>
                    <label className="font-semibold">Rector's Signature:</label>
                    <div className="flex items-center mt-2">
                      <img
                          src="/assets/images/rector-signature.jpg"
                          alt="Rector's Signature"
                          className="h-16 object-contain"
                          style={{ background: '#fff', borderRadius: '4px', border: '1px solid #eee', padding: '4px' }}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="font-semibold">Rectors Remark:</label>
                    <textarea
                      className="border rounded px-2 py-1 w-full"
                      rows={2}
                      value="Average performance needs more improvement"
                      readOnly
                      disabled
                      placeholder="Rectors Remark"
                    />
                  </div>
                </div>
                <div className="mb-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="font-semibold">Academic Session:</label>
                    <input
                      type="text"
                      className="border rounded px-2 py-1 w-full"
                      value="2025/2026"
                      readOnly
                      disabled
                      placeholder="Academic Session"
                    />
                  </div>
                  <div>
                    <label className="font-semibold">Next Term Begins:</label>
                    <input
                      type="text"
                      className="border rounded px-2 py-1 w-full"
                      value="25/09/2026"
                      readOnly
                      disabled
                      placeholder="Next Term Begins"
                    />
                  </div>
                </div>
                <div className="flex gap-4 mt-4">
                    {/* 2. In your Save button handler, replace the payload logic with this: */}
                    <Button
                      variant="secondary"
                      type="button"
                      disabled={isSubmitting || isReadOnly} // <-- Disable if already pushed
                      className="w-full"
                      onClick={async () => {
                        setSuccessMsg('');
                        setErrorMsg('');
                        setIsSubmitting(true);

                        // Always send isPush: false for draft save
                        const payload = buildSaveAllPayload(selectedStudent._id, false);

                        try {
                          const res = await fetch(`${API_BASE_URL}/api/results/save-all`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(payload),
                          });
                          const data = await res.json();
                          if (data.success) {
                            setSuccessMsg('Result saved as draft.');
                            setDirtyStudents(prev => ({ ...prev, [selectedStudent._id]: false }));
                          } else {
                            setErrorMsg('Failed to save result. Please try again.');
                          }
                        } catch (err) {
                          setErrorMsg('Failed to save result. Please try again.');
                        }
                        setIsSubmitting(false);
                      }}
                    >
                      <Icon name="Save" size={16} className="mr-2" />
                      Save
                    </Button>
                    <Button
                      variant="primary"
                      type="button"
                      disabled={isSubmitting || isReadOnly || resultsPushed[selectedStudent._id]}
                      className="w-full"
                      onClick={() => {
                        setPendingPushStudentId(selectedStudent._id);
                        setShowPushConfirm(true);
                      }}
                    >
                      {isSubmitting ? (
                        <>
                          <TbFidgetSpinner className="animate-spin mr-2" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Icon name="Send" size={16} className="mr-2" />
                          {resultsPushed[selectedStudent._id] ? "Already Pushed" : "Save & Push Result"}
                        </>
                      )}
                    </Button>
                    {isReadOnly && (
                      <div className="mt-4 text-warning text-center font-semibold">
                        Results have been submitted for admin verification.<br />
                        You cannot modify again.
                      </div>
                    )}
                  </div>
              </form>
              {/* Move the modal here, inside the result setter */}
              {showPushConfirm && (
                <Modal
                  isOpen={showPushConfirm}
                  onClose={() => setShowPushConfirm(false)}
                  title="Confirm Push"
                >
                  <div>
                    <p>Are you sure you want to push this student's result? This will submit the result for admin verification and make it read-only.</p>
                    <div className="flex gap-4 mt-4">
                      <Button
                        variant="primary"
                        onClick={() => handlePushIndividualResult(pendingPushStudentId)}
                        disabled={isSubmitting}
                      >
                        Yes, Push Result
                      </Button>
                      <Button
                        variant="secondary"
                        onClick={() => setShowPushConfirm(false)}
                        disabled={isSubmitting}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                </Modal>
              )}

              

              {/* Delete Subject Confirmation Modal */}
              {showDeleteSubjectConfirm && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
                  <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-sm text-center">
                    <h3 className="font-bold text-lg mb-4">Confirm Subject Removal</h3>
                    <p className="mb-4">
                      Are you <span className="font-semibold text-red-600">sure</span> you want to remove the subject{" "}
                      <span className="font-bold text-primary">{showDeleteSubjectConfirm}</span> for all students?
                    </p>
                    <div className="flex justify-center gap-4 mt-6">
                      <button
                        className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition"
                        onClick={() => {
                          handleRemoveSubject(showDeleteSubjectConfirm);
                          setShowDeleteSubjectConfirm(null);
                        }}
                      >
                        Yes, Remove
                      </button>
                      <button
                        className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 transition"
                        onClick={() => setShowDeleteSubjectConfirm(null)}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
    );
    }

    // Otherwise, show the student list
    return (
        <>
            <RoleBasedHeader
                userRole="teacher"
                userName={teacherData?.name || 'Teacher'}
                isCollapsed={false}
            />
            <main className="pt-20 pb-10 bg-background min-h-screen">
                <div className="max-w-5xl mx-auto px-2 sm:px-4">
                    <div className="mb-8">
                        <h1 className="font-heading text-3xl font-bold text-primary mb-2">
                            Result Portal - {terms.find(t => t.value === selectedTerm)?.label}
                        </h1>
                        <p className="text-muted-foreground text-lg">
                            Click a student to enter their result.
                        </p>
                    </div>

{/* General Push Button */}
<div className="flex justify-end mb-4">
  <Button
    variant="primary"
    disabled={
      isGeneralPushing ||
      students.length === 0 ||
      students.every(s => resultsPushed[s._id])
    }
    onClick={() => setShowGeneralPushConfirm(true)}
    className="w-full sm:w-auto"
  >
    {isGeneralPushing ? (
      <>
        <TbFidgetSpinner className="animate-spin mr-2" />
        Pushing All...
      </>
    ) : (
      <>
        <Icon name="Send" size={16} className="mr-2" />
        Push All Results to Admin
      </>
    )}
  </Button>
</div>

{/* Student Grid */}
{isLoadingStudents ? (
    <div className="flex flex-col items-center justify-center py-12">
        <TbFidgetSpinner className="animate-spin text-5xl text-primary mb-2" />
        <span className="text-primary font-medium">Loading students...</span>
    </div>
) : (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {students.map(student => (
            <div
                key={student._id}
                className="relative bg-card border border-border rounded-lg shadow p-4 flex flex-col items-center cursor-pointer hover:bg-primary/10 transition"
                onClick={() => setSelectedStudent(student)}
            >
                {/* Pushed badge */}
                {resultsPushed[student._id] && (
                    <span className="absolute top-2 left-2 bg-green-600 text-white text-xs font-bold px-2 py-1 rounded shadow z-10">
                        Pushed
                    </span>
                )}
                <span className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-xl font-bold text-white border-2 border-primary shadow mb-2">
                  {student.name ? student.name.charAt(0).toUpperCase() : "S"}
                </span>
                <span className="font-body font-medium text-foreground">{student.name}</span>
                <span className="text-xs text-muted-foreground">{student.className}</span>
            </div>
        ))}
    </div>
)}

{/* General Push Confirmation Modal (should be here!) */}
{showGeneralPushConfirm && (
  <Modal
    isOpen={showGeneralPushConfirm}
    onClose={() => setShowGeneralPushConfirm(false)}
    title="Confirm Push All"
  >
    <div>
      <p>
        Are you sure you want to push <b>all students' results</b> to admin? This will submit all results for admin verification and make them read-only.
      </p>
      <div className="flex gap-4 mt-4">
        <Button
          variant="primary"
          onClick={() => {
            setShowGeneralPushConfirm(false);
            handleGeneralPush();
          }}
          disabled={isGeneralPushing}
        >
          Yes, Push All Results
        </Button>
        <Button
          variant="secondary"
          onClick={() => setShowGeneralPushConfirm(false)}
          disabled={isGeneralPushing}
        >
          Cancel
        </Button>
      </div>
    </div>
  </Modal>
)}
                </div>
            </main>
            {/* Feedback message area for student list */}
            {(successMsg || errorMsg) && (
              <div
                className={`fixed bottom-6 left-1/2 transform -translate-x-1/2 px-4 py-2 rounded-lg font-medium text-center shadow-lg z-50 transition-all ${
                    successMsg
                      ? 'bg-green-100 text-green-700 border border-green-300'
                      : 'bg-red-100 text-red-700 border border-red-300'
                }`}
                style={{ minWidth: '280px', maxWidth: '90vw' }}
              >
                {successMsg || errorMsg}
                <button
                  className="ml-2 text-xs text-gray-500 hover:text-gray-700"
                  onClick={() => {
                    setSuccessMsg('');
                    setErrorMsg('');
                  }}
                  aria-label="Dismiss"
                >
                  &times;
                </button>
              </div>
            )}

            {/* Confirmation Modal */}
            {showPushConfirm && (
              <Modal
                isOpen={showPushConfirm}
                onClose={() => setShowPushConfirm(false)}
                title="Confirm Push"
              >
                <div>
                  <p>Are you sure you want to push this student's result? This will submit the result for admin verification and make it read-only.</p>
                  <div className="flex gap-4 mt-4">
                    <Button
                      variant="primary"
                      onClick={() => handlePushIndividualResult(pendingPushStudentId)}
                      disabled={isSubmitting}
                    >
                      Yes, Push Result
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={() => setShowPushConfirm(false)}
                      disabled={isSubmitting}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              </Modal>
            )}
        </>
    );
};

export default ResultPortal;